const express = require('express');
const router = express.Router();
const { db, auth } = require('../config/firebase');
const { verifyToken, requireRole } = require('../middleware/auth');

// Create user (admin only)
router.post('/create', verifyToken, requireRole('admin'), async (req, res) => {
  try {
    const { email, password, name, role, phone, specialty, licenseNumber } = req.body;
    const userRecord = await auth.createUser({ email, password, displayName: name });

    const userData = {
      uid: userRecord.uid,
      email,
      name,
      role,
      phone: phone || '',
      specialty: specialty || '',
      licenseNumber: licenseNumber || '',
      status: 'active',
      createdAt: new Date().toISOString(),
      createdBy: req.user.uid,
    };

    await db.collection('users').doc(userRecord.uid).set(userData);
    await db.collection('logs').add({
      action: 'USER_CREATED',
      targetId: userRecord.uid,
      targetName: name,
      role,
      performedBy: req.user.uid,
      performedByName: req.user.userData?.name || 'Admin',
      timestamp: new Date().toISOString(),
    });

    res.status(201).json({ message: 'User created', user: userData });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all users
router.get('/', verifyToken, requireRole('admin', 'receptionist', 'doctor'), async (req, res) => {
  try {
    const { role } = req.query;
    let query = db.collection('users');
    if (role) query = query.where('role', '==', role);
    const snapshot = await query.get();
    const users = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get current user profile
router.get('/me', verifyToken, async (req, res) => {
  try {
    const doc = await db.collection('users').doc(req.user.uid).get();
    res.json({ id: doc.id, ...doc.data() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update user
router.put('/:id', verifyToken, requireRole('admin'), async (req, res) => {
  try {
    const updates = req.body;
    delete updates.uid;
    delete updates.email;
    updates.updatedAt = new Date().toISOString();
    await db.collection('users').doc(req.params.id).update(updates);
    res.json({ message: 'User updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Toggle user status
router.patch('/:id/status', verifyToken, requireRole('admin'), async (req, res) => {
  try {
    const { status } = req.body;
    await db.collection('users').doc(req.params.id).update({ status, updatedAt: new Date().toISOString() });
    res.json({ message: 'Status updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
