import React, { useState, useEffect } from 'react';
import api from '../../utils/api';
import toast from 'react-hot-toast';
import { UserPlus, Search, Stethoscope, Activity, X, ShieldCheck } from 'lucide-react';

function AddDoctorModal({ onClose, onSaved }) {
  const [form, setForm] = useState({
    name: '', email: '', password: '', role: 'doctor',
    phone: '', specialty: '', licenseNumber: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault(); setLoading(true);
    try {
      await api.post('/users/create', form);
      toast.success('Doctor account created!');
      onSaved(); onClose();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to create doctor');
    } finally { setLoading(false); }
  };

  return (
    <div className="modal-overlay">
      <div className="modal modal-lg">
        <div className="modal-header">
          <h3 className="modal-title">🩺 Add Doctor</h3>
          <button className="btn btn-ghost btn-icon" onClick={onClose}><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-grid cols-2">
              <div className="form-group" style={{ gridColumn: '1/-1' }}>
                <label className="form-label">Full Name *</label>
                <input className="form-input" value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  required placeholder="Dr. Full Name" />
              </div>
              <div className="form-group">
                <label className="form-label">Email *</label>
                <input className="form-input" type="email" value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Password *</label>
                <input className="form-input" type="password" value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  required minLength={6} placeholder="Min. 6 characters" />
              </div>
              <div className="form-group">
                <label className="form-label">Phone</label>
                <input className="form-input" value={form.phone}
                  onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                  placeholder="+91 XXXXX XXXXX" />
              </div>
              <div className="form-group">
                <label className="form-label">Specialty *</label>
                <select className="form-select" value={form.specialty}
                  onChange={e => setForm(f => ({ ...f, specialty: e.target.value }))} required>
                  <option value="">Select specialty</option>
                  {['General Medicine', 'Cardiology', 'Orthopedics', 'Pediatrics',
                    'Neurology', 'Dermatology', 'ENT', 'Gynecology',
                    'Ophthalmology', 'Psychiatry', 'Surgery', 'Oncology',
                    'Nephrology', 'Gastroenterology', 'Pulmonology'].map(s => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">License Number *</label>
                <input className="form-input" value={form.licenseNumber}
                  onChange={e => setForm(f => ({ ...f, licenseNumber: e.target.value }))}
                  placeholder="MCI-XXXXXXXX" required />
              </div>
            </div>

            <div style={{ marginTop: 16, padding: '12px 16px', background: 'var(--indigo-dim)', borderRadius: 10, border: '1px solid var(--border-active)' }}>
              <div style={{ fontSize: '0.78rem', color: 'var(--indigo)', fontWeight: 600 }}>
                ℹ️ This will create a Doctor login account. The doctor can login at the Doctor portal with these credentials.
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? <Activity size={15} className="spinning" /> : <UserPlus size={15} />}
              Create Doctor Account
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default function AdminDoctors() {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);

  const load = async () => {
    try {
      const res = await api.get('/users?role=doctor');
      setDoctors(res.data);
    } catch { toast.error('Failed to load doctors'); } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const toggleStatus = async (id, current) => {
    const status = current === 'active' ? 'inactive' : 'active';
    try {
      await api.patch(`/users/${id}/status`, { status });
      toast.success(`Doctor ${status}`);
      load();
    } catch { toast.error('Failed'); }
  };

  const filtered = doctors.filter(d =>
    d.name?.toLowerCase().includes(search.toLowerCase()) ||
    d.specialty?.toLowerCase().includes(search.toLowerCase()) ||
    d.email?.toLowerCase().includes(search.toLowerCase())
  );

  const SPECIALTY_COLORS = {
    'General Medicine': 'blue', 'Cardiology': 'red', 'Orthopedics': 'yellow',
    'Pediatrics': 'green', 'Neurology': 'purple', 'Dermatology': 'pink',
    'ENT': 'blue', 'Gynecology': 'pink', 'Surgery': 'red', 'Oncology': 'orange',
  };

  return (
    <div>
      <div className="section-header">
        <div>
          <h2 className="section-title">🩺 Doctors Management</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', marginTop: 2 }}>
            {doctors.length} registered doctors
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <div className="search-bar">
            <Search size={15} />
            <input placeholder="Search doctors..." value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <UserPlus size={15} /> Add Doctor
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stat-grid" style={{ marginBottom: 24 }}>
        {[
          { label: 'Total Doctors', value: doctors.length, color: 'var(--emerald)', bg: 'var(--emerald-dim)', accent: 'linear-gradient(90deg,#10b981,#059669)' },
          { label: 'Active', value: doctors.filter(d => d.status !== 'inactive').length, color: 'var(--indigo)', bg: 'var(--indigo-dim)', accent: 'linear-gradient(90deg,#6366f1,#8b5cf6)' },
          { label: 'Specialties', value: new Set(doctors.map(d => d.specialty).filter(Boolean)).size, color: 'var(--violet)', bg: 'var(--violet-dim)', accent: 'linear-gradient(90deg,#8b5cf6,#a78bfa)' },
          { label: 'Inactive', value: doctors.filter(d => d.status === 'inactive').length, color: 'var(--rose)', bg: 'var(--rose-dim)', accent: 'linear-gradient(90deg,#f43f5e,#fb7185)' },
        ].map(({ label, value, color, bg, accent }) => (
          <div key={label} className="stat-card" style={{ '--card-accent': accent }}>
            <div className="stat-icon" style={{ background: bg }}><Stethoscope size={22} color={color} /></div>
            <div className="stat-info">
              <div className="stat-label">{label}</div>
              <div className="stat-value" style={{ color }}>{value}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="table-wrap">
          {loading ? (
            <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}><Activity size={20} className="spinning" /></div>
          ) : filtered.length === 0 ? (
            <div className="empty-state">
              <Stethoscope size={40} />
              <h3>No doctors found</h3>
              <p>Add the first doctor using the button above</p>
            </div>
          ) : (
            <table>
              <thead>
                <tr><th>Doctor</th><th>Specialty</th><th>Email</th><th>Phone</th><th>License</th><th>Status</th><th>Action</th></tr>
              </thead>
              <tbody>
                {filtered.map(doc => (
                  <tr key={doc.uid || doc.id}>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{
                          width: 40, height: 40, borderRadius: 12,
                          background: 'linear-gradient(135deg,#10b981,#059669)',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                          fontSize: '0.82rem', fontWeight: 800, color: '#fff', flexShrink: 0,
                        }}>
                          {(doc.name || 'D').split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div style={{ fontWeight: 700 }}>{doc.name}</div>
                          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>Doctor</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      {doc.specialty ? (
                        <span className={`badge ${SPECIALTY_COLORS[doc.specialty] || 'indigo'}`}>
                          {doc.specialty}
                        </span>
                      ) : <span style={{ color: 'var(--text-muted)' }}>—</span>}
                    </td>
                    <td style={{ color: 'var(--text-secondary)', fontSize: '0.82rem' }}>{doc.email}</td>
                    <td style={{ color: 'var(--text-muted)' }}>{doc.phone || '—'}</td>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.78rem', fontFamily: 'monospace' }}>{doc.licenseNumber || '—'}</td>
                    <td><span className={`badge ${doc.status === 'inactive' ? 'red' : 'green'}`}>{doc.status === 'inactive' ? 'Inactive' : 'Active'}</span></td>
                    <td>
                      <button
                        className={`btn btn-sm ${doc.status === 'inactive' ? 'btn-success' : 'btn-danger'}`}
                        onClick={() => toggleStatus(doc.uid || doc.id, doc.status)}>
                        {doc.status === 'inactive' ? 'Activate' : 'Deactivate'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {showModal && <AddDoctorModal onClose={() => setShowModal(false)} onSaved={load} />}
    </div>
  );
}
